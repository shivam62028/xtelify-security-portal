import os
from dotenv import load_dotenv
import google.generativeai as genai
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

# Load the local .env vault
load_dotenv()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure Gemini
genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))
model = genai.GenerativeModel('gemini-1.5-pro')

@app.post("/api/analyze")
async def analyze_vulnerability(request: Request):
    data = await request.json()
    description = data.get('description', '')
    asset = data.get('asset', '')
    evidence = data.get('evidence', '')
    
    prompt = f"""
    Act as an expert DevSecOps engineer. Analyze this security vulnerability and provide the exact code patch, terminal command, or configuration change required to remediate it. Format the output in clean Markdown.
    
    Asset: {asset}
    Description: {description}
    Evidence: {evidence}
    """
    
    response = model.generate_content(prompt)
    return {"remediation": response.text}

# import os
# from dotenv import load_dotenv
# import google.generativeai as genai
# from fastapi import FastAPI, Request
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.staticfiles import StaticFiles
# from fastapi.responses import FileResponse

# load_dotenv()

# app = FastAPI()

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))
# model = genai.GenerativeModel('gemini-1.5-pro')

# # 1. Your API Route
# @app.post("/api/analyze")
# async def analyze_vulnerability(request: Request):
#     data = await request.json()
#     description = data.get('description', '')
#     asset = data.get('asset', '')
#     evidence = data.get('evidence', '')
    
#     prompt = f"""
#     Act as an expert DevSecOps engineer. Analyze this security vulnerability and provide the exact code patch, terminal command, or configuration change required to remediate it. Format the output in clean Markdown.
    
#     Asset: {asset}
#     Description: {description}
#     Evidence: {evidence}
#     """
    
#     response = model.generate_content(prompt)
#     return {"remediation": response.text}

# # 2. Serve React Static Files (Bypassing Nginx)
# app.mount("/assets", StaticFiles(directory="dist/assets"), name="assets")

# # 3. Catch-all route to serve the React index.html
# @app.get("/{full_path:path}")
# async def serve_react(full_path: str):
#     return FileResponse("dist/index.html")